<?php

require_once dirname(__FILE__).'/CredisSentinelTest.php';

class CredisStandaloneSentinelTest extends CredisSentinelTest
{
    protected $useStandalone = TRUE;
}
